<h2>Add New Book</h2>
<form method="POST" enctype="multipart/form-data" action="{{ route('books.store') }}">
    @include('books.form', ['buttonText' => 'Create'])
</form>
