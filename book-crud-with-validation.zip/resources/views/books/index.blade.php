<a href="{{ route('books.create') }}">Add Book</a>
<ul>
    @foreach ($books as $book)
        <li>
            <strong>{{ $book->title }}</strong> by {{ $book->author }}
            <a href="{{ route('books.edit', $book) }}">Edit</a>
            <form action="{{ route('books.destroy', $book) }}" method="POST" style="display:inline;">
                @csrf @method('DELETE')
                <button type="submit">Delete</button>
            </form>
        </li>
    @endforeach
</ul>
