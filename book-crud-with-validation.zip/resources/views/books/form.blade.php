@csrf
@if ($errors->any())
    <div style="color:red;">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<label>Title: <input type="text" name="title" value="{{ old('title', $book->title ?? '') }}"></label><br>
<label>Author: <input type="text" name="author" value="{{ old('author', $book->author ?? '') }}"></label><br>
<label>ISBN: <input type="text" name="isbn" value="{{ old('isbn', $book->isbn ?? '') }}"></label><br>
<label>Publish Date: <input type="date" name="publish_date" value="{{ old('publish_date', $book->publish_date ?? '') }}"></label><br>
<label>Cover Image: <input type="file" name="cover_image"></label><br>
<button type="submit">{{ $buttonText }}</button>
