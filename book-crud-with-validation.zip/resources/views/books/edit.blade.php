<h2>Edit Book</h2>
<form method="POST" enctype="multipart/form-data" action="{{ route('books.update', $book) }}">
    @method('PUT')
    @include('books.form', ['buttonText' => 'Update'])
</form>
